create function edit_child(par_efirstc text, par_elastc text, par_ebirthc date, par_eagec bigint, par_ediagnosisc text) returns TABLE(first_name text, last_name text, birthdate date, age bigint, diagnosis text)
LANGUAGE plpgsql
AS $$
BEGIN
			  update child_info set first_name = par_efirstc, last_name = par_elastc, birthdate = par_ebirthc, age = par_eagec, diagnosis = par_ediagnosisc
        where child_info.first_name = par_efirstc;

         RETURN query select child_info.first_name, child_info.last_name, child_info.birthdate, child_info.age, child_info.diagnosis from child_info WHERE child_info.first_name = par_efirstc;
  END
$$;
