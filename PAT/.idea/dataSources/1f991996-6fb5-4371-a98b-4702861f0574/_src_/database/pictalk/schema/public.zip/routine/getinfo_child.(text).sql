create function getinfo_child(par_efirstc text, OUT text, OUT text, OUT date, OUT bigint, OUT text) returns SETOF record
LANGUAGE SQL
AS $$
select first_name, last_name, birthdate, age, diagnosis from child_info;
$$;
