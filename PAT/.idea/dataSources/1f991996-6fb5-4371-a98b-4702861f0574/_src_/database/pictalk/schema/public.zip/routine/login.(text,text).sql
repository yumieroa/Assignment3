create function login(par_email text, par_password text) returns text
LANGUAGE plpgsql
AS $$
declare
    loc_eml text;
    loc_pwd text;
    loc_res text;
  begin
     select into loc_eml email, loc_pwd, password from account
       where email = par_email and password = par_password;

     if loc_eml isnull AND loc_pwd isnull then
       loc_res = 'Error';
     else
       loc_res = 'ok';
     end if;
     return loc_res;
  end;
$$;
