create function registration(par_username text, par_email text, par_password text, par_repeat text) returns text
LANGUAGE plpgsql
AS $$
DECLARE
    loc_repeat text;
    loc_email    text;
		loc_username text;
		loc_password text;
    loc_res      text;
    begin
			SELECT into loc_username "username", loc_email "email", loc_password "password" from account ;
			if loc_username notnull and loc_password notnull THEN
        loc_res =  loc_username;

        insert into account (username,password,email) values (par_username,par_password,par_email);
			else
					loc_res =  'Error';
			end if;
			return loc_res;
	END;


$$;
