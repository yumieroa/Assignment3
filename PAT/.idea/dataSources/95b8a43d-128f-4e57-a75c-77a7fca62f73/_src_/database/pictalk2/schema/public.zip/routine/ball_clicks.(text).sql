create function ball_clicks(par_ball text) returns text
LANGUAGE plpgsql
AS $$
declare
    loc_res text;

  begin
     if par_ball NOTNULL then
        UPDATE toys set clicks = clicks+1 where toy_id = 5;
         loc_res = 'ok';
      else
       loc_res = 'Error';
     end if;
     return loc_res;
  end;
$$;
