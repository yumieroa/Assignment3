create function car_clicks(par_car text) returns text
LANGUAGE plpgsql
AS $$
declare
    loc_res text;

  begin
     if par_car NOTNULL then
        UPDATE toys set clicks = clicks+1 where toy_id = 9;
         loc_res = 'ok';
      else
       loc_res = 'Error';
     end if;
     return loc_res;
  end;
$$;
