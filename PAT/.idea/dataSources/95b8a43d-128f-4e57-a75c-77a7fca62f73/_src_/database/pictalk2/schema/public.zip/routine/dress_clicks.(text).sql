create function dress_clicks(par_dress text) returns text
LANGUAGE plpgsql
AS $$
declare
    loc_res text;

  begin
     if par_dress NOTNULL then
        UPDATE clothes set clicks = clicks+1 where cloth_id = 5;
         loc_res = 'ok';
      else
       loc_res = 'Error';
     end if;
     return loc_res;
  end;
$$;
