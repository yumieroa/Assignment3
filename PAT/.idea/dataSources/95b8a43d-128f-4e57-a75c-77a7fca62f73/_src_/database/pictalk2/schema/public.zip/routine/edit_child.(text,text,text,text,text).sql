create function edit_child(par_efirstc text, par_elastc text, par_ebirthc text, par_eagec text, par_edisorderc text) returns text
LANGUAGE plpgsql
AS $$
declare
    loc_res text;

    loc_efirstc text;
    loc_elastc text;
    loc_ebirthc text;
    loc_eagec text;
    loc_edisorderc text;
  begin
     select into loc_efirstc first_name, loc_elastc last_name, loc_ebirthc birthdate, loc_eagec age, loc_edisorderc diagnosis from child_info;
     if par_elastc NOTNULL then

       delete from child_info;
       insert into child_info ( first_name, last_name, birthdate, age, diagnosis) values (par_efirstc,par_elastc,par_ebirthc,par_eagec,par_edisorderc);
       loc_res = 'ok';

     else
       loc_res = 'Error';
     end if;
     return loc_res;
  end;
$$;
