create function edit_parent(par_efirstp text, par_elastp text, par_ebirthp date, par_eagep bigint, par_rltnshp text) returns text
LANGUAGE plpgsql
AS $$
declare
    loc_res text;

    loc_efirstp text;
    loc_elastp text;
    loc_ebirthp text;
    loc_eagep text;
    loc_rlntshp text;
  begin
     select into loc_efirstp first_name, loc_elastp last_name, loc_ebirthp birthdate, loc_eagep age, loc_rlntshp relationship from parent_info;
     if par_elastp NOTNULL then

       delete from parent_info;
       insert into parent_info (first_name, last_name, birthdate, age, relationship) values (par_efirstp,par_elastp,par_ebirthp,par_eagep,par_rltnshp);
       loc_res = 'ok';

     else
       loc_res = 'Error';
     end if;
     return loc_res;
  end;
$$;
