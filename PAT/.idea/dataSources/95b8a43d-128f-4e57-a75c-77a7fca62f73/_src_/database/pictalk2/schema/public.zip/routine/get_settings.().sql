create function get_settings(OUT text, OUT text, OUT text) returns SETOF record
LANGUAGE SQL
AS $$
select email, username, pass from account;
$$;
