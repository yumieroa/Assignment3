create function getclicks_clothes(OUT text, OUT integer) returns SETOF record
LANGUAGE SQL
AS $$
select cloth_name, clicks from clothes where clicks > 0 order by cloth_id;
$$;
