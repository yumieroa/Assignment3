create function getclicks_food(OUT character varying, OUT integer, OUT character varying, OUT character varying, OUT character varying, OUT character varying, OUT character varying, OUT character varying, OUT character varying, OUT character varying) returns SETOF record
LANGUAGE SQL
AS $$
select food_name, clicks, casein, gluten, calories, calories_total, protein, protein_total, cholesterol, cholesterol_total  from food  where clicks > 0 order by food_id;
$$;
