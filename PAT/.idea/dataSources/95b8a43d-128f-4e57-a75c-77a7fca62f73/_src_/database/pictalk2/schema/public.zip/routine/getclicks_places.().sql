create function getclicks_places(OUT text, OUT integer) returns SETOF record
LANGUAGE SQL
AS $$
select place_name, clicks from places where clicks > 0 order by place_id;
$$;
