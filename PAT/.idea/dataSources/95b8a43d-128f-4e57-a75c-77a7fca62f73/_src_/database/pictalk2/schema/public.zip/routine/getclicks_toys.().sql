create function getclicks_toys(OUT text, OUT integer) returns SETOF record
LANGUAGE SQL
AS $$
select toy_name, clicks from toys where clicks > 0 order by toy_id;
$$;
