create function getinfo_child(OUT text, OUT text, OUT text, OUT text, OUT text) returns SETOF record
LANGUAGE SQL
AS $$
select first_name, last_name, birthdate, age, diagnosis from child_info;
$$;
