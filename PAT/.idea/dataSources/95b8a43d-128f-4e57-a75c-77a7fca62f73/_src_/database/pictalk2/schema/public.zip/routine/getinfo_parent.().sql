create function getinfo_parent(OUT text, OUT text, OUT date, OUT bigint, OUT text) returns SETOF record
LANGUAGE SQL
AS $$
select first_name, last_name, birthdate, age, relationship from parent_info;
$$;
