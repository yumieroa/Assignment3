create function getpassword(par_email text) returns text
LANGUAGE plpgsql
AS $$
declare
    loc_password text;
  begin
     select into loc_password password from account where email = par_email;
     if loc_password isnull then
       loc_password = 'null';
     end if;
     return loc_password;
 end;
$$;
