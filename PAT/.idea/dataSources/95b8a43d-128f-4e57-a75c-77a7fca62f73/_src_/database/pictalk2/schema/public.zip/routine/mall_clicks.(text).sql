create function mall_clicks(par_play text) returns text
LANGUAGE plpgsql
AS $$
declare
    loc_res text;

  begin
     if par_play NOTNULL then
        UPDATE places set clicks = clicks+1 where place_id = 8;
         loc_res = 'ok';
      else
       loc_res = 'Error';
     end if;
     return loc_res;
  end;
$$;
