create function mcdo_clicks(par_mcdo text) returns text
LANGUAGE plpgsql
AS $$
declare
    loc_res text;

  begin
     if par_mcdo NOTNULL then
        UPDATE places set clicks = clicks+1 where place_id = 3;
         loc_res = 'ok';
      else
       loc_res = 'Error';
     end if;
     return loc_res;
  end;
$$;
