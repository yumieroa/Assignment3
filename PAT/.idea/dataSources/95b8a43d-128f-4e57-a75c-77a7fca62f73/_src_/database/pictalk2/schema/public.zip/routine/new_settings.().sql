create function new_settings(OUT text, OUT text, OUT text) returns SETOF record
LANGUAGE SQL
AS $$
select email, username, password from account;
$$;
