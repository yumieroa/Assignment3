create function pancakes_clicks(par_pancakes text) returns text
LANGUAGE plpgsql
AS $$
declare
    loc_res text;

  begin
     if par_pancakes NOTNULL then
        UPDATE food set clicks = clicks+1 where food_id = 3;
        UPDATE FOOD set calories_total=  (cast( calories as INT) * cast ( clicks as int ) ) where food_id = 3;
        UPDATE FOOD set protein_total=  (cast( protein as INT) * cast ( clicks as int ) ) where food_id = 3;
        UPDATE FOOD set cholesterol_total=  (cast( cholesterol as INT) * cast ( clicks as int ) ) where food_id = 3;
         loc_res = 'ok';
      else
       loc_res = 'Error';
     end if;
     return loc_res;
  end;
$$;
