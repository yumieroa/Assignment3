create function panty_clicks(par_panty text) returns text
LANGUAGE plpgsql
AS $$
declare
    loc_res text;

  begin
     if par_panty NOTNULL then
        UPDATE clothes set clicks = clicks+1 where cloth_id = 1;
         loc_res = 'ok';
      else
       loc_res = 'Error';
     end if;
     return loc_res;
  end;
$$;
