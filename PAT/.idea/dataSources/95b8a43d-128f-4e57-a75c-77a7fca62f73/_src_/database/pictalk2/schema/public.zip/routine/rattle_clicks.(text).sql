create function rattle_clicks(par_rattle text) returns text
LANGUAGE plpgsql
AS $$
declare
    loc_res text;

  begin
     if par_rattle NOTNULL then
        UPDATE toys set clicks = clicks+1 where toy_id = 4;
         loc_res = 'ok';
      else
       loc_res = 'Error';
     end if;
     return loc_res;
  end;
$$;
