create function shorts_clicks(par_shrt text) returns text
LANGUAGE plpgsql
AS $$
declare
    loc_res text;

  begin
     if par_shrt NOTNULL then
        UPDATE clothes set clicks = clicks+1 where cloth_id = 2;
         loc_res = 'ok';
      else
       loc_res = 'Error';
     end if;
     return loc_res;
  end;
$$;
