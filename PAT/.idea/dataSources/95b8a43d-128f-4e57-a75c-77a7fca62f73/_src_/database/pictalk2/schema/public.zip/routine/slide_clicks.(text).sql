create function slide_clicks(par_slide text) returns text
LANGUAGE plpgsql
AS $$
declare
    loc_res text;

  begin
     if par_slide NOTNULL then
        UPDATE toys set clicks = clicks+1 where toy_id = 12;
         loc_res = 'ok';
      else
       loc_res = 'Error';
     end if;
     return loc_res;
  end;
$$;
