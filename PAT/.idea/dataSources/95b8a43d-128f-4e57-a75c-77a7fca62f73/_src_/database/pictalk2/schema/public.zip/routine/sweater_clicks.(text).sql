create function sweater_clicks(par_sweater text) returns text
LANGUAGE plpgsql
AS $$
declare
    loc_res text;

  begin
     if par_sweater NOTNULL then
        UPDATE clothes set clicks = clicks+1 where cloth_id = 8;
         loc_res = 'ok';
      else
       loc_res = 'Error';
     end if;
     return loc_res;
  end;
$$;
