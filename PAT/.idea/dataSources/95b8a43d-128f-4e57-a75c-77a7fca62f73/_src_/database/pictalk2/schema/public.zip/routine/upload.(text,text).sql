create function upload(par_name text, par_img text) returns text
LANGUAGE plpgsql
AS $$
declare
    loc_res text;

    loc_name text;
    loc_img text;

  begin
     select into loc_name food_name, loc_img food_img from food;
     if loc_name NOTNULL then

       insert into food (food_name, food_img) values (par_name,par_img);
       loc_res = 'ok';

     else
       loc_res = 'Error';
     end if;
     return loc_res;
  end;
$$;
