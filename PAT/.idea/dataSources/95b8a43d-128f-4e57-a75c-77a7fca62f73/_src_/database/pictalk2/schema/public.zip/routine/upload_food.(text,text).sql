create function upload_food(par_fdname text, par_fdimg text) returns text
LANGUAGE plpgsql
AS $$
DECLARE
    loc_res text;
  BEGIN
      INSERT INTO food(food_name, food_img)
      VALUES (par_fdname, par_fdimg);
    loc_res = 'stored';
    return loc_res;
  END;
$$;
